<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class identity_proof extends Model
{
  protected $table = 'identity_proof';
   /* public function user()
    {
        return $this->belongsTo('App\user');
    } */
}
