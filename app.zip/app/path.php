<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class path extends Model
{
     protected $table = 'path';
	 protected $fillable  = ['url'];
}
